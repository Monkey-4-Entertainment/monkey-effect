const {app,BrowserWindow,Menu,dialog,shell}=require('electron');
const path=require('node:path'),fs=require('node:fs'),{pathToFileURL}=require('node:url');
const arg=n=>{const i=process.argv.indexOf(n);return i>=0?process.argv[i+1]:null;};
const bundleRoot=path.resolve(__dirname,'../../..');
const portableData=fs.existsSync(path.join(bundleRoot,'Data'))?path.join(bundleRoot,'Data'):null;
if(arg('--profile')||portableData)app.setPath('userData',path.resolve(arg('--profile')||path.join(portableData,'Profile')));
app.setName('Monkey Max4');app.enableSandbox();app.commandLine.appendSwitch('autoplay-policy','no-user-gesture-required');
let host,quitting=false;const windows=new Map(),proof=arg('--launch-proof');
const routes={account:'/hub.html',game:'/game.html',settings:'/settings.html'};
const manualUpdateUrl=url=>/^https:\/\/raw\.githubusercontent\.com\/Monkey-4-Entertainment\/monkey-effect\/main\/games\/monkey-max4\/Monkey-Max4-Update-0\.16\.x-to-\d+\.\d+\.\d+\.zip$/.test(url);
function openWindow(kind){
 let w=windows.get(kind);if(w&&!w.isDestroyed()){if(w.isMinimized())w.restore();if(new URL(w.webContents.getURL()||host.origin).pathname!==routes[kind])w.ready=w.loadURL(host.origin+routes[kind]);w.show();w.focus();return w;}
 const game=kind==='game';w=new BrowserWindow({title:'Monkey Max4 · '+(game?'สนามเกม':kind==='settings'?'ตั้งค่าไลฟ์':'สมาชิก'),width:game?1440:1180,height:game?820:880,minWidth:game?800:760,minHeight:540,show:false,backgroundColor:'#080f19',icon:path.join(__dirname,'game/dist/assets/brand/app.ico'),webPreferences:{nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,backgroundThrottling:false}});windows.set(kind,w);
 w.webContents.setWindowOpenHandler(({url})=>{const u=new URL(url);if(u.origin===host.origin){const k=Object.keys(routes).find(k=>routes[k]===u.pathname);if(k)openWindow(k);}else if(manualUpdateUrl(url))void shell.openExternal(url);return {action:'deny'};});
 w.webContents.on('will-navigate',(e,url)=>{if(new URL(url).origin!==host.origin){e.preventDefault();if(manualUpdateUrl(url))void shell.openExternal(url);}});
 w.webContents.on('page-title-updated',e=>{e.preventDefault();w.setTitle('Monkey Max4 — '+(game?'สนามเกม':kind==='settings'?'ตั้งค่าไลฟ์':'สมาชิก'));});
 w.webContents.session.setPermissionRequestHandler((wc,p,cb)=>cb(false));w.webContents.session.setPermissionCheckHandler(()=>false);
 w.on('closed',()=>windows.delete(kind));w.once('ready-to-show',()=>{if(!proof)w.show();});w.ready=w.loadURL(host.origin+routes[kind]);return w;
}
if(!app.requestSingleInstanceLock())app.quit();else{
 app.on('second-instance',()=>{if(host)openWindow('account');});
 app.whenReady().then(async()=>{
  const dataDir=path.resolve(arg('--data-dir')||(portableData?path.join(portableData,'GameData'):path.join(app.getPath('userData'),'data')));
  const log=(event,details={})=>{try{fs.mkdirSync(dataDir,{recursive:true});fs.appendFileSync(path.join(dataDir,'startup.log'),JSON.stringify({time:new Date().toISOString(),event,...details})+'\n','utf8');}catch{}};
  try{
  log('starting',{version:require('./package.json').version});
  const {createHost,createPreset}=await import(pathToFileURL(path.join(__dirname,'game/server/host.mjs')).href);
  const {createDesktopUpdateOptions}=require('./update-client.cjs');
  const updateOptions=createDesktopUpdateOptions({bundleRoot,appDirectory:__dirname,beforeShutdown:async()=>{
   const game=windows.get('game');if(game&&!game.isDestroyed())await game.webContents.executeJavaScript('globalThis.monkeyMax4PrepareUpdate ? globalThis.monkeyMax4PrepareUpdate() : Promise.resolve(true)');
  },cancelShutdown:async()=>{const game=windows.get('game');if(game&&!game.isDestroyed())await game.webContents.executeJavaScript('globalThis.monkeyMax4CancelUpdate && globalThis.monkeyMax4CancelUpdate()');},shutdown:()=>app.quit()});
  host=await createHost({port:proof?0:4327,dataDir,updateOptions});
  const {writeLivePreset,runOptionalPresetTasks}=require('./live-preset.cjs');
  const tasks=[{name:'livePresets',run:()=>writeLivePreset(path.resolve(dataDir,'../../LIVE-Kit'))}];
  if(!proof)tasks.push({name:'monkeyEffectPreset',run:()=>{const target=path.resolve(dataDir,'../../MonkeyEffect');fs.mkdirSync(target,{recursive:true});const file=path.join(target,'Monkey-Max4-MonkeyEffect.json');fs.writeFileSync(file,JSON.stringify(createPreset(host.origin,fs.readFileSync(path.join(dataDir,'connector-key.txt'),'utf8').trim()),null,2));return {file};}});
  const optionalPresets=runOptionalPresetTasks(tasks,warning=>log('preset-warning',warning));
  const livePresets=optionalPresets.results.livePresets||{rebased:false,warnings:optionalPresets.warnings};
  Menu.setApplicationMenu(Menu.buildFromTemplate([{label:'Monkey Max4',submenu:[{label:'บัญชีสมาชิก',click:()=>openWindow('account')},{label:'สนามเกม',click:()=>openWindow('game')},{label:'ตั้งค่าไลฟ์',click:()=>openWindow('settings')},{type:'separator'},{role:'togglefullscreen',label:'เต็มหน้าจอ'},{role:'resetZoom',label:'ขนาดปกติ'},{role:'quit',label:'ออกจากเกม'}]}]));
  const account=openWindow('account');await account.ready;log('account-loaded',{origin:host.origin,presetWarnings:optionalPresets.warnings.length});
  if(proof){const game=openWindow('game'),settings=openWindow('settings');await Promise.all([game.ready,settings.ready]);fs.writeFileSync(proof,JSON.stringify({loaded:true,origin:host.origin,version:require('./package.json').version,electron:process.versions.electron,sandbox:true,livePresets,windows:[...windows].map(([kind,w])=>({kind,id:w.id,url:w.webContents.getURL(),title:w.getTitle(),nodeIntegration:w.webContents.getLastWebPreferences().nodeIntegration,contextIsolation:w.webContents.getLastWebPreferences().contextIsolation}))}));app.quit();}
 }catch(e){log('startup-error',{code:e.code||'',message:e.message});if(proof){fs.writeFileSync(proof,JSON.stringify({loaded:false,error:e.message}));}else dialog.showErrorBox('Monkey Max4',e.code==='EADDRINUSE'?'พอร์ต 4327 ถูกใช้อยู่ กรุณาปิดเกมรถรุ่นอื่นก่อน':e.message);app.exit(1);}});
 app.on('window-all-closed',()=>app.quit());app.on('before-quit',()=>{if(!quitting){quitting=true;if(host)void host.close();}});
}
