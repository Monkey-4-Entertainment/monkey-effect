import {request} from 'node:https';
import {lookup} from 'node:dns';
import {BlockList,isIP} from 'node:net';
import {Readable} from 'node:stream';
import {safeAvatar} from '../dist/social.mjs';

export const AVATAR_MAX_BYTES=2*1024*1024;
export const AVATAR_TIMEOUT_MS=5000;
const failed=(message,status=502)=>Object.assign(Error(message),{status});
const deniedIPv4=new BlockList();
for(const [ip,prefix]of [['0.0.0.0',8],['10.0.0.0',8],['100.64.0.0',10],['127.0.0.0',8],['169.254.0.0',16],['172.16.0.0',12],['192.0.0.0',24],['192.0.2.0',24],['192.168.0.0',16],['198.18.0.0',15],['198.51.100.0',24],['203.0.113.0',24],['224.0.0.0',4],['240.0.0.0',4]])deniedIPv4.addSubnet(ip,prefix,'ipv4');
const globalIPv6=new BlockList();globalIPv6.addSubnet('2000::',3,'ipv6');
const deniedIPv6=new BlockList();for(const [ip,prefix]of [['2001::',23],['2001:db8::',32],['2002::',16]])deniedIPv6.addSubnet(ip,prefix,'ipv6');
export function isPublicAvatarAddress(address){const family=isIP(address);return family===4?!deniedIPv4.check(address,'ipv4'):family===6&&globalIPv6.check(address,'ipv6')&&!deniedIPv6.check(address,'ipv6');}

// Validate the actual address selected for the TLS connection, rather than doing
// a separate DNS check followed by an unpinned second lookup in fetch().
function publicLookup(hostname,options,callback){
 lookup(hostname,{all:true,verbatim:true},(error,addresses)=>{
  if(error)return callback(error);
  const safe=addresses.filter(item=>isPublicAvatarAddress(item.address));
  if(!safe.length)return callback(failed('ไม่สามารถโหลดรูปผู้ส่งจากปลายทางนี้ได้'));
  if(options?.all)return callback(null,safe);
  const address=safe.find(item=>!options?.family||item.family===options.family)||safe[0];callback(null,address.address,address.family);
 });
}
export function avatarNetworkFetch(url,{signal,headers}={}){
 return new Promise((resolve,reject)=>{
  const req=request(url,{method:'GET',signal,lookup:publicLookup,headers},response=>{
   const values=new Headers();for(const name of ['location','content-type','content-length'])if(response.headers[name]!==undefined)values.set(name,String(response.headers[name]));
   resolve({status:response.statusCode,headers:values,body:Readable.toWeb(response)});
  });
  req.once('error',reject);req.end();
 });
}

function avatarURL(value){
 const safe=safeAvatar(value);if(!safe||!safe.startsWith('https://'))throw failed('ลิงก์รูปผู้ส่งไม่ถูกต้อง',400);
 const url=new URL(safe);url.hash='';return url.href;
}
function matchesImage(bytes,type){
 if(type==='image/png')return bytes.length>=8&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
 if(type==='image/jpeg')return bytes.length>=3&&bytes[0]===255&&bytes[1]===216&&bytes[2]===255;
 if(type==='image/gif')return bytes.length>=6&&['GIF87a','GIF89a'].includes(bytes.subarray(0,6).toString('ascii'));
 if(type==='image/webp')return bytes.length>=12&&bytes.subarray(0,4).toString('ascii')==='RIFF'&&bytes.subarray(8,12).toString('ascii')==='WEBP';
 return false;
}
async function discard(response){try{await response?.body?.cancel();}catch{}}

export function createAvatarProxy({fetchImpl=avatarNetworkFetch,maxBytes=AVATAR_MAX_BYTES,timeoutMs=AVATAR_TIMEOUT_MS,maxEntries=64,maxCacheBytes=16*1024*1024,cacheTTL=10*60*1000,maxInflight=8,now=Date.now}={}){
 const cache=new Map(),inflight=new Map();let cacheBytes=0;
 const remove=key=>{const item=cache.get(key);if(item){cacheBytes-=item.bytes.length;cache.delete(key);}};
 async function download(initial,signal){
  let url=initial;const visited=new Set();
  for(let redirects=0;redirects<=3;redirects++){
   if(signal.aborted)throw signal.reason;
   if(visited.has(url))throw failed('ลิงก์รูปผู้ส่งวนซ้ำ');visited.add(url);
   const response=await fetchImpl(url,{method:'GET',redirect:'manual',credentials:'omit',signal,headers:{Accept:'image/jpeg,image/png,image/webp,image/gif','Accept-Encoding':'identity'}});
   if([301,302,303,307,308].includes(response.status)){
    const location=response.headers.get('location');await discard(response);
    if(!location||redirects===3)throw failed('ลิงก์รูปผู้ส่งเปลี่ยนปลายทางมากเกินไป');
    try{url=avatarURL(new URL(location,url).href);}catch{throw failed('ปลายทางรูปผู้ส่งไม่ถูกต้อง',400);}continue;
   }
   if(response.status!==200){await discard(response);throw failed('โหลดรูปผู้ส่งไม่สำเร็จ');}
   const type=response.headers.get('content-type')?.split(';')[0].trim().toLowerCase();
   if(!['image/jpeg','image/png','image/webp','image/gif'].includes(type)){await discard(response);throw failed('รองรับรูป JPEG, PNG, WebP และ GIF เท่านั้น',415);}
   const declared=response.headers.get('content-length');if(declared!==null&&(!/^\d+$/.test(declared)||Number(declared)>maxBytes)){await discard(response);throw failed('ไฟล์รูปผู้ส่งใหญ่เกินกำหนด',413);}
   if(!response.body?.getReader){await discard(response);throw failed('รูปผู้ส่งไม่มีข้อมูล');}
   const reader=response.body.getReader(),chunks=[];let size=0;
   try{
    while(true){
     if(signal.aborted)throw signal.reason;
     const {done,value}=await reader.read();if(done)break;
     size+=value.byteLength;if(size>maxBytes)throw failed('ไฟล์รูปผู้ส่งใหญ่เกินกำหนด',413);
     chunks.push(Buffer.from(value));
    }
   }catch(error){try{await reader.cancel();}catch{}throw error;}finally{reader.releaseLock();}
   const bytes=Buffer.concat(chunks,size);if(!matchesImage(bytes,type))throw failed('ข้อมูลรูปผู้ส่งไม่ตรงกับชนิดไฟล์',415);
   return{bytes,type};
  }
  throw failed('โหลดรูปผู้ส่งไม่สำเร็จ');
 }
 async function get(value){
  const url=avatarURL(value),cached=cache.get(url);
  if(cached&&cached.until>now()){cache.delete(url);cache.set(url,cached);return cached;}
  remove(url);if(inflight.has(url))return inflight.get(url);
  if(inflight.size>=maxInflight)throw failed('กำลังโหลดรูปผู้ส่ง กรุณาลองใหม่',503);
  const controller=new AbortController();let timer;
  const deadline=new Promise((resolve,reject)=>{timer=setTimeout(()=>{const error=failed('โหลดรูปผู้ส่งเกินเวลาที่กำหนด',504);controller.abort(error);reject(error);},timeoutMs);});
  const task=Promise.race([download(url,controller.signal),deadline]).then(value=>{
   const item={...value,until:now()+cacheTTL};
   if(item.bytes.length<=maxCacheBytes){
    while(cache.size>=maxEntries||cacheBytes+item.bytes.length>maxCacheBytes)remove(cache.keys().next().value);
    cache.set(url,item);cacheBytes+=item.bytes.length;
   }
   return item;
  }).catch(error=>{if(error.status)throw error;throw failed('โหลดรูปผู้ส่งไม่สำเร็จ');}).finally(()=>{clearTimeout(timer);inflight.delete(url);});
  inflight.set(url,task);return task;
 }
 return{get,stats(){return{entries:cache.size,bytes:cacheBytes,inflight:inflight.size};}};
}
