import {readFileSync,writeFileSync,renameSync,existsSync} from 'node:fs';
import {randomUUID} from 'node:crypto';
import {MAPS} from '../dist/maps.mjs';
import {GIFTS} from '../dist/engine.mjs';
import {SOCIAL} from '../dist/social.mjs';
import {VEHICLES,DEFAULT_VEHICLE_ID} from '../dist/vehicle-catalog.mjs';
const fail=(m,s=422)=>Object.assign(Error(m),{status:s});
export class ControlRoom {
 constructor(file){this.file=file;this.users=existsSync(file)?JSON.parse(readFileSync(file,'utf8')):{};this.rooms=new Map();}
 room(owner){if(!this.rooms.has(owner))this.rooms.set(owner,{commands:[],state:null,lastSeen:0});return this.rooms.get(owner);}
 settings(owner){const settings={map:'aurora',vehicle:DEFAULT_VEHICLE_ID,auto:false,muted:false,volume:.65,musicVolume:.22,engineVolume:.8,...this.users[owner]};if(!Object.hasOwn(VEHICLES,settings.vehicle))settings.vehicle=DEFAULT_VEHICLE_ID;return settings;}
 update(owner,data){const next=this.settings(owner);for(const [key,value]of Object.entries(data)){
  if(key==='map'&&Object.hasOwn(MAPS,value))next.map=value;
  else if(key==='vehicle'&&typeof value==='string'&&Object.hasOwn(VEHICLES,value))next.vehicle=value;
  else if(['auto','muted'].includes(key)&&typeof value==='boolean')next[key]=value;
  else if(['volume','musicVolume','engineVolume'].includes(key)&&Number.isFinite(value)&&value>=0&&value<=1)next[key]=value;
  else throw fail('ค่าตั้งค่าไม่ถูกต้อง');
 }this.users[owner]=next;writeFileSync(this.file+'.tmp',JSON.stringify(this.users));renameSync(this.file+'.tmp',this.file);return next;}
 command(owner,body){const r=this.room(owner);if(Date.now()-r.lastSeen>5000)throw fail('เปิดหน้าต่างเกมก่อนส่งคำสั่ง',409);
  const {action,value}=body;
  if(!['start','pause','wins','winDelta','gift','social','together'].includes(action))throw fail('คำสั่งไม่ถูกต้อง');
  if(action==='wins'&&(!Number.isSafeInteger(value)))throw fail('จำนวนวินไม่ถูกต้อง');
  if(action==='winDelta'&&![1,-1].includes(value))throw fail('เพิ่มหรือลดครั้งละ 1 วิน');
  if(action==='gift'&&!Object.hasOwn(GIFTS,value)||action==='social'&&!Object.hasOwn(SOCIAL,value))throw fail('ไม่พบเอฟเฟกต์');
  if(r.commands.length>=100)throw fail('คำสั่งเต็ม กรุณารอ',429);
  const command={id:randomUUID(),action,value};r.commands.push(command);return command;
 }
 poll(owner,body){const r=this.room(owner);const acks=new Set(Array.isArray(body.commandAcks)?body.commandAcks:[]);r.commands=r.commands.filter(c=>!acks.has(c.id));
  r.lastSeen=Date.now();const state=body.state;if(state&&typeof state==='object')r.state=Object.fromEntries(['mode','wins','distance','score','wallHP','fuel','map','soundReady'].filter(k=>['string','number','boolean'].includes(typeof state[k])).map(k=>[k,state[k]]));
  return {settings:this.settings(owner),commands:r.commands};
 }
 status(owner){const r=this.room(owner);return {settings:this.settings(owner),state:r.state,connected:Date.now()-r.lastSeen<5000,pendingCommands:r.commands.length};}
}
