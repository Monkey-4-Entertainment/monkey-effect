import {randomBytes,createHash} from 'node:crypto';
import {mkdir,mkdtemp,open,unlink,lstat} from 'node:fs/promises';
import {closeSync,fstatSync,lstatSync,openSync,opendirSync,readSync} from 'node:fs';
import path from 'node:path';

export const UPDATE_PRODUCT='monkey-max4';
export const UPDATE_BASE='https://raw.githubusercontent.com/Monkey-4-Entertainment/monkey-effect/main/games/monkey-max4/';
export const UPDATE_FEED=UPDATE_BASE+'latest.json';
const MAX_ZIP_BYTES=95*1024*1024,MAX_FEED_BYTES=64*1024;
const MAX_RESULT_BYTES=16*1024,MAX_RESULT_ENTRIES=512;
const fail=(message,status=400)=>Object.assign(Error(message),{status});
const semver=value=>typeof value==='string'&&/^(0|[1-9]\d{0,3})\.(0|[1-9]\d{0,3})\.(0|[1-9]\d{0,3})$/.test(value);
export function compareVersions(a,b){
 if(!semver(a)||!semver(b))throw fail('หมายเลขเวอร์ชันอัปเดตไม่ถูกต้อง',502);
 const aa=a.split('.').map(Number),bb=b.split('.').map(Number);
 for(let i=0;i<3;i++)if(aa[i]!==bb[i])return Math.sign(aa[i]-bb[i]);return 0;
}
function asset(value,version,kind){
 if(!value||typeof value!=='object'||Array.isArray(value))throw fail('รายการไฟล์อัปเดตไม่ครบ',502);
 let url;try{url=new URL(value.url);}catch{throw fail('ลิงก์อัปเดตไม่ถูกต้อง',502);}
 const base=new URL(UPDATE_BASE),filename=kind==='auto'?`Monkey-Max4-AutoUpdate-${version}.zip`:`Monkey-Max4-Update-0.16.x-to-${version}.zip`;
 if(url.origin!==base.origin||url.pathname!==base.pathname+filename||url.search||url.hash||url.username||url.password)throw fail('ไฟล์อัปเดตอยู่นอกโฟลเดอร์ Monkey Max4',502);
 if(typeof value.sha256!=='string'||!/^[a-f0-9]{64}$/.test(value.sha256)||!Number.isSafeInteger(value.bytes)||value.bytes<100||value.bytes>MAX_ZIP_BYTES)throw fail('ขนาดหรือลายพิมพ์ไฟล์อัปเดตไม่ถูกต้อง',502);
 return {url:url.href,sha256:value.sha256,bytes:value.bytes};
}
export function validateUpdateFeed(value){
 if(!value||typeof value!=='object'||Array.isArray(value)||value.schemaVersion!==1||value.product!==UPDATE_PRODUCT||!semver(value.version))throw fail('เซิร์ฟเวอร์ส่งข้อมูลอัปเดตของเกมไม่ถูกต้อง',502);
 const automatic=asset(value.package,value.version,'auto'),manual=asset(value.manual,value.version,'manual');
 const from=value.package.fromVersions;
 if(value.package.kind!=='runtime-overlay'||!Array.isArray(from)||!from.length||from.length>30||from.some(v=>!semver(v)||compareVersions(v,value.version)>=0)||new Set(from).size!==from.length)throw fail('รายการเวอร์ชันที่อัปเดตได้ไม่ถูกต้อง',502);
 if(!Array.isArray(value.notes)||value.notes.length>20||value.notes.some(s=>typeof s!=='string'||s.length>700))throw fail('รายละเอียดอัปเดตไม่ถูกต้อง',502);
 return {product:UPDATE_PRODUCT,version:value.version,notes:[...value.notes],package:{...automatic,kind:'runtime-overlay',fromVersions:[...from]},manual};
}
async function readLimited(response,maxBytes){
 if(!response.body)throw fail('ไม่พบข้อมูลอัปเดตจากเซิร์ฟเวอร์',502);
 const chunks=[],reader=response.body.getReader();let size=0;
 try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>maxBytes)throw fail('ข้อมูลอัปเดตมีขนาดเกินกำหนด',502);chunks.push(value);}}
 catch(error){try{await reader.cancel();}catch{}throw error;}finally{reader.releaseLock();}
 return Buffer.concat(chunks.map(v=>Buffer.from(v)),size);
}
async function noLinkedAncestors(directory){
 let cursor=path.resolve(directory);
 while(true){
  try{if((await lstat(cursor)).isSymbolicLink())throw fail('โฟลเดอร์อัปเดตต้องไม่เป็นลิงก์ไปที่อื่น',409);}
  catch(error){if(error.code!=='ENOENT')throw error;}
  const parent=path.dirname(cursor);if(parent===cursor)break;cursor=parent;
 }
}
function existingUnlinkedPath(file){
 let cursor=path.resolve(file);
 while(true){
  if(lstatSync(cursor).isSymbolicLink())return false;
  const parent=path.dirname(cursor);if(parent===cursor)return true;cursor=parent;
 }
}
// The helper outlives the desktop host. Show its last relevant failure when the
// old game reopens, without returning local paths or raw exception messages.
function previousInstallError(downloadRoot,version){
 if(typeof downloadRoot!=='string'||!downloadRoot)return null;
 let directory;
 try{
  const root=path.resolve(downloadRoot);
  if(!existingUnlinkedPath(root)||!lstatSync(root).isDirectory())return null;
  directory=opendirSync(root);let latest=null,entry,seen=0;
  while(seen++<MAX_RESULT_ENTRIES&&(entry=directory.readSync())){
   if(!/^max4-[A-Za-z0-9]{6}$/.test(entry.name)||!entry.isDirectory()||entry.isSymbolicLink())continue;
   const job=path.join(root,entry.name),file=path.join(job,'update-result.json');let handle;
   try{
    if(!existingUnlinkedPath(file))continue;
    const before=lstatSync(file);
    if(!before.isFile()||before.size<2||before.size>MAX_RESULT_BYTES)continue;
    handle=openSync(file,'r');const stat=fstatSync(handle);
    if(!stat.isFile()||stat.size!==before.size||stat.dev!==before.dev||stat.ino!==before.ino)continue;
    const bytes=Buffer.alloc(stat.size+1),length=readSync(handle,bytes,0,bytes.length,0);
    if(length!==stat.size||!existingUnlinkedPath(file))continue;
    const value=JSON.parse(bytes.subarray(0,length).toString('utf8'));
    if(!value||typeof value!=='object'||Array.isArray(value)||value.product!==undefined&&value.product!==UPDATE_PRODUCT||value.currentVersion!==version||!semver(value.targetVersion)||compareVersions(value.targetVersion,version)<=0||typeof value.ok!=='boolean'||typeof value.installed!=='boolean'||!['verify','verified','stage','wait','install','rollback','installed','restart','complete'].includes(value.phase))continue;
    if(!latest||stat.mtimeMs>latest.time||stat.mtimeMs===latest.time&&entry.name>latest.name)latest={time:stat.mtimeMs,name:entry.name,value};
   }catch{}finally{if(handle!==undefined)try{closeSync(handle);}catch{}}
  }
  if(latest&&!latest.value.ok&&!latest.value.installed)return `อัปเดตเป็นเวอร์ชัน ${latest.value.targetVersion} ครั้งก่อนไม่สำเร็จ เกมยังเป็นเวอร์ชัน ${version} กรุณาปิดหน้าต่างเกมอื่น แล้วกดตรวจอัปเดตเพื่อลองอีกครั้ง`;
 }catch{}finally{if(directory)try{directory.closeSync();}catch{}}
 return null;
}
export class UpdateService {
 constructor({version,fetchImpl=fetch,downloadRoot=null,onInstall=null}={}){
  if(!semver(version))throw Error('Invalid installed update version');
  this.version=version;this.fetch=fetchImpl;this.downloadRoot=downloadRoot;this.onInstall=onInstall;
  this.token=randomBytes(32).toString('hex');this.state='idle';this.feed=null;this.error=null;this.progress=null;this.task=null;this.checkTask=null;this.installScheduled=false;
  if(this.onInstall){this.error=previousInstallError(this.downloadRoot,this.version);if(this.error)this.state='error';}
 }
 status(){const available=Boolean(this.feed&&compareVersions(this.feed.version,this.version)>0);return {product:UPDATE_PRODUCT,currentVersion:this.version,runtime:this.onInstall?'desktop':'browser',state:this.state,latestVersion:this.feed?.version||null,available,canInstall:Boolean(available&&this.state==='available'&&!this.checkTask&&!this.task&&!this.installScheduled&&this.onInstall&&this.downloadRoot&&this.feed.package.fromVersions.includes(this.version)),notes:this.feed?.notes||[],progress:this.progress?{...this.progress}:null,error:this.error,downloadUrl:available?this.feed.manual.url:null,token:this.token};}
 async check(){
  if(this.installScheduled||this.task)return this.status();
  if(this.checkTask){await this.checkTask;return this.status();}
  this.state='checking';this.error=null;this.progress=null;
  const task=(async()=>{
   try{
    const response=await this.fetch(UPDATE_FEED,{headers:{Accept:'application/json','Cache-Control':'no-cache'},redirect:'error',signal:AbortSignal.timeout(10000)});
    if(!response.ok)throw fail(response.status===404?'ยังไม่พบเวอร์ชันบนเซิร์ฟเวอร์อัปเดต':'ติดต่อเซิร์ฟเวอร์อัปเดตไม่สำเร็จ',502);
    const bytes=await readLimited(response,MAX_FEED_BYTES);let feed;try{feed=JSON.parse(bytes.toString('utf8'));}catch{throw fail('อ่านข้อมูลเวอร์ชันจากเซิร์ฟเวอร์ไม่ได้',502);}
    this.feed=validateUpdateFeed(feed);this.state=compareVersions(this.feed.version,this.version)>0?'available':'upToDate';
   }catch(error){this.state='error';this.feed=null;this.error=error.name==='TimeoutError'||error.name==='AbortError'?'ตรวจอัปเดตหมดเวลา กรุณาลองอีกครั้ง':error.message||'ตรวจอัปเดตไม่สำเร็จ';}
  })();this.checkTask=task.finally(()=>{this.checkTask=null;});
  await this.checkTask;return this.status();
 }
 install(){
  if(this.task||this.installScheduled)return this.status();
  if(this.checkTask)throw fail('กำลังตรวจเวอร์ชัน กรุณารอสักครู่',409);
  if(!this.status().canInstall)throw fail('รุ่นนี้ต้องดาวน์โหลดชุดอัปเดตไปติดตั้งด้วยตนเอง',409);
  const feed=this.feed;this.state='downloading';this.error=null;this.progress={received:0,total:feed.package.bytes,percent:0};
  this.task=this.downloadAndInstall(feed).catch(error=>{this.installScheduled=false;this.state='error';this.error=error.name==='TimeoutError'||error.name==='AbortError'?'ดาวน์โหลดอัปเดตหมดเวลา กรุณาลองอีกครั้ง':error.message||'ติดตั้งอัปเดตไม่สำเร็จ';}).finally(()=>{this.task=null;});
  return this.status();
 }
 async downloadAndInstall(feed){
  await noLinkedAncestors(this.downloadRoot);
  await mkdir(this.downloadRoot,{recursive:true});await noLinkedAncestors(this.downloadRoot);
  const job=await mkdtemp(path.join(this.downloadRoot,'max4-'));await noLinkedAncestors(job);
  const file=path.join(job,'update.zip');let handle;
  try{
   const response=await this.fetch(feed.package.url,{headers:{Accept:'application/zip'},redirect:'error',signal:AbortSignal.timeout(180000)});
   if(!response.ok||!response.body)throw fail('ดาวน์โหลดไฟล์อัปเดตไม่สำเร็จ',502);
   const advertised=response.headers.get('content-length');if(advertised!==null&&Number(advertised)!==feed.package.bytes)throw fail('ขนาดไฟล์จากเซิร์ฟเวอร์ไม่ตรงกับเวอร์ชัน',502);
   await noLinkedAncestors(job);
   handle=await open(file,'wx',0o600);const hash=createHash('sha256'),reader=response.body.getReader();let received=0;
   try{while(true){const {done,value}=await reader.read();if(done)break;received+=value.byteLength;if(received>feed.package.bytes)throw fail('ไฟล์อัปเดตมีขนาดเกินรายการที่ตรวจไว้',502);hash.update(value);await handle.writeFile(value);this.progress={received,total:feed.package.bytes,percent:Math.floor(received/feed.package.bytes*100)};}}
   catch(error){try{await reader.cancel();}catch{}throw error;}finally{reader.releaseLock();}
   await handle.sync();await handle.close();handle=null;
   if(received!==feed.package.bytes||hash.digest('hex')!==feed.package.sha256)throw fail('ไฟล์อัปเดตตรวจสอบไม่ผ่าน กรุณาดาวน์โหลดใหม่',502);
   this.state='installing';this.installScheduled=true;await this.onInstall({job,archive:file,sha256:feed.package.sha256,bytes:feed.package.bytes,currentVersion:this.version,targetVersion:feed.version});
  }catch(error){if(handle)try{await handle.close();}catch{}try{await unlink(file);}catch{}throw error;}
 }
}
