import {createLiveMembership} from './membership.mjs';
import {ControlRoom} from './control.mjs';
import {createAvatarProxy} from './avatar.mjs';
import {UpdateService} from './update-service.mjs';
import http from 'node:http';
import {readFileSync,writeFileSync,mkdirSync,existsSync,appendFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {randomBytes,timingSafeEqual,createHash} from 'node:crypto';
import {GIFTS} from '../dist/engine.mjs';
import {GIFT_CATALOG} from '../dist/gift-catalog.mjs';
import {createGamePreset} from '../dist/preset.mjs';
import {SOCIAL,LIKES_PER_BOMB,SHARES_PER_VIEWER,viewerProfile,AVATAR_CSP} from '../dist/social.mjs';
export const PORT=4327;
export const LIVE_LEASE_MS=7000;
export const GIFT_NAMES=Object.fromEntries(Object.entries(GIFT_CATALOG).map(([id,g])=>[id,g.giftName]));
export function createPreset(origin,key){return createGamePreset(origin,key);}
const failure=(message,status=400)=>Object.assign(Error(message),{status});
export class Receipts{
 constructor(file){this.file=file;this.seen=new Map();this.totals=new Map();this.actions=new Map();this.likes=new Map();this.shares=new Map();this.pending=new Map();this.received=0;this.archived=0;this.archivedPieces=0;this.recovered=0;this.recoveredPieces=0;
  if(file&&existsSync(file)){const rows=readFileSync(file,'utf8').trim().split('\n').filter(Boolean);for(let i=0;i<rows.length;i++){let row;try{row=JSON.parse(rows[i]);}catch{throw Error('บันทึกของขวัญเสียหาย กรุณาเก็บไฟล์ receipts.jsonl เพื่อตรวจสอบ');}this.replay(row);}
   // New receipts have a durable delivery checkpoint and can be resumed. Old
   // versions acknowledged only after the animation; replaying their unresolved
   // rows could award a win twice, so only pre-upgrade rows remain archived.
   for(const [id,row]of this.pending){if(row.ledgerRevision===2){this.recovered++;this.recoveredPieces+=row.quantity;}else{this.archived++;this.archivedPieces+=row.quantity;this.pending.delete(id);}}
  }
 }
 scope(owner,kind,parts,legacy){return owner===undefined||owner===null?legacy:JSON.stringify(['owner',owner,kind,...parts]);}
 legacyScope(owner,kind,value){
  if(owner===undefined||owner===null)return value;
  let parts;try{parts=JSON.parse(value);}catch{}
  if(!Array.isArray(parts))return this.scope(owner,kind,[value],value);
  return this.scope(owner,kind,kind==='social'&&parts[0]==='social'?parts.slice(1):parts,value);
 }
 likeScope(owner,viewer){return this.scope(owner,'likes',[viewer],viewer);}
 shareScope(owner,viewer){return this.scope(owner,'shares',[viewer],viewer);}
 replay(row){
  if(row.type==='receipt'){
   const event=row.ledgerRevision===2?row.eventId:this.legacyScope(row.owner,'gift',row.eventId),combo=row.ledgerRevision===2?row.combo:this.legacyScope(row.owner,'combo',row.combo);
   this.seen.set(event,row.hash);this.totals.set(combo,Math.max(this.totals.get(combo)||0,row.total));
   if(!this.actions.has(combo))this.actions.set(combo,row.action);
   this.received+=row.quantity;if(row.quantity)this.pending.set(row.id,row);
  }
  if(row.type==='social'){
   const event=row.ledgerRevision===2?row.id:this.legacyScope(row.owner,'social',row.id);
   this.seen.set(event,row.hash);if(row.action==='like')this.likes.set(this.likeScope(row.owner,row.user.id),row.remainder);
   if(row.action==='share'){
    const scope=this.shareScope(row.owner,row.user.id),previous=this.shares.get(scope)||0;
    // Legacy share rows also consume the allowance. A new game's round, ACK,
    // reload or host restart must never grant that viewer ten more bike spawns.
    this.shares.set(scope,Math.min(SHARES_PER_VIEWER,Math.max(previous,Number.isSafeInteger(row.shareTotal)?row.shareTotal:previous+row.quantity)));
   }
   this.received+=row.quantity;if(row.quantity)this.pending.set(row.id,row);
  }
  if(row.type==='ack')for(const id of row.ids)this.pending.delete(id);
 }
 save(row){if(this.file)appendFileSync(this.file,JSON.stringify(row)+'\n',{encoding:'utf8'});this.replay(row);}
 accept(action,p,owner){
  if(Object.hasOwn(SOCIAL,action))return this.acceptSocial(action,p,owner);
  if(GIFT_CATALOG[action]?.pendingVideo)throw failure('เอฟเฟกต์นี้กำลังรอคลิป ยังไม่เปิดรับของขวัญ',409);
  if(!Object.hasOwn(GIFTS,action))throw failure('Unknown gift effect');
  if(p.get('protocol')!=='mekong-combo-v1'||p.get('countMode')!=='cumulative')throw failure('ใช้ Combo-Fix จากชุดเกมก่อนนำเข้าพรีเซ็ต',426);
  const eventId=p.get('eventId'),user=p.get('uniqueId'),comboId=p.get('comboId'),giftId=p.get('giftId'),total=Number(p.get('repeatCount')),end=p.get('repeatEnd');
  if([eventId,user,comboId,giftId].some(s=>!s||s.length>160||/[\u0000-\u001f]/.test(s))||!Number.isSafeInteger(total)||total<1||total>100000||!['true','false'].includes(end))throw failure('Invalid combo receipt');
  const combo=this.scope(owner,'combo',[user,giftId,comboId],JSON.stringify([user,giftId,comboId]));const eventKey=this.scope(owner,'gift',[user,eventId],JSON.stringify([user,eventId]));const hash=createHash('sha256').update(JSON.stringify([action,user,comboId,giftId,total,end])).digest('hex');
  if(this.seen.has(eventKey)){if(this.seen.get(eventKey)!==hash)throw failure('รหัสรายการซ้ำแต่ข้อมูลไม่ตรงกัน',409);return{ok:true,duplicate:true,quantity:0};}
  if(this.actions.has(combo)&&this.actions.get(combo)!==action)throw failure('คอมโบนี้ผูกกับเอฟเฟกต์อื่นแล้ว กรุณาใช้คอมโบใหม่',409);
  const old=this.totals.get(combo)||0,quantity=Math.max(0,total-old);if(quantity&&this.pending.size>=10000)throw failure('คิวเต็ม กรุณาลองส่งรายการเดิมใหม่',503);
  const profile=viewerProfile({id:user,name:p.get('nickname')||user,avatarUrl:p.get('avatarUrl')||p.get('profilePictureUrl')||p.get('profilePicturUrl')||''});
  const row={ledgerRevision:2,owner,type:'receipt',id:eventKey,eventId:eventKey,hash,combo,total:Math.max(total,old),quantity,action,name:profile.name,user:profile,comboEnd:end==='true',time:Date.now()};this.save(row);return{ok:true,quantity,status:quantity?'queued':'duplicate-total'};
 }
 acceptSocial(action,p,owner){
  if(!Object.hasOwn(SOCIAL,action))throw failure('Unknown social effect');
  if(p.get('protocol')!=='mekong-combo-v1'||p.get('countMode')!=='delta')throw failure('ใช้ Combo-Fix ส่งกิจกรรมผู้ชมแบบ delta',426);
  const event=p.get('eventId'),viewer=p.get('uniqueId'),count=Number(p.get('repeatCount'));
  if([event,viewer].some(s=>!s||s.length>160||/[\u0000-\u001f]/.test(s))||!Number.isSafeInteger(count)||count<1||count>100000)throw failure('Invalid social receipt');
  const id=this.scope(owner,'social',[viewer,event],JSON.stringify(['social',viewer,event])),hash=createHash('sha256').update(JSON.stringify([action,viewer,count])).digest('hex');
  const shared=this.shares.get(this.shareScope(owner,viewer))||0,shareState=action==='share'?{limit:SHARES_PER_VIEWER,remaining:Math.max(0,SHARES_PER_VIEWER-shared)}:{};
  if(this.seen.has(id)){if(this.seen.get(id)!==hash)throw failure('รหัสรายการซ้ำแต่ข้อมูลไม่ตรงกัน',409);return {ok:true,duplicate:true,quantity:0,...shareState};}
  const total=(this.likes.get(this.likeScope(owner,viewer))||0)+count,quantity=action==='like'?Math.floor(total/LIKES_PER_BOMB):action==='share'?Math.min(count,shareState.remaining):count,remainder=action==='like'?total%LIKES_PER_BOMB:0;
  if(quantity&&this.pending.size>=10000)throw failure('คิวเต็ม กรุณาลองส่งรายการเดิมใหม่',503);
  const user=viewerProfile({id:viewer,name:p.get('nickname')||viewer,avatarUrl:p.get('avatarUrl')||p.get('profilePictureUrl')||p.get('profilePicturUrl')||''});
  this.save({ledgerRevision:2,owner,type:'social',id,hash,action,user,name:user.name,quantity,remainder,...(action==='share'?{requestedCount:count,shareTotal:shared+quantity}:{}),time:Date.now()});
  return {ok:true,quantity,remainder,threshold:LIKES_PER_BOMB,status:quantity?'queued':action==='share'?'share-limit':'counted',...shareState,...(action==='share'?{remaining:shareState.remaining-quantity}:{})};
 }
 ack(ids){const found=ids.filter(id=>this.pending.has(id));if(found.length)this.save({type:'ack',ids:found,time:Date.now()});}
}
export async function createHost({port=PORT,dataDir=path.resolve('data'),membershipFetch=fetch,avatarFetch,updateOptions={}}={}){
 mkdirSync(dataDir,{recursive:true});const keyfile=path.join(dataDir,'connector-key.txt');if(!existsSync(keyfile))writeFileSync(keyfile,randomBytes(32).toString('hex'),{flag:'wx'});const key=readFileSync(keyfile,'utf8').trim();
 const storeFile=path.join(dataDir,'delivery-store-id.txt');if(!existsSync(storeFile))writeFileSync(storeFile,randomBytes(16).toString('hex'),{flag:'wx'});const storeId=readFileSync(storeFile,'utf8').trim();
 const receipts=new Receipts(path.join(dataDir,'receipts.jsonl'));const dist=path.resolve(fileURLToPath(new URL('../dist/',import.meta.url)));let active=null,origin,membership;const control=new ControlRoom(path.join(dataDir,'settings.json')),avatars=createAvatarProxy({fetchImpl:avatarFetch});
 const read=async(req,limit=65536)=>{const chunks=[];let size=0;for await(const b of req){size+=b.length;if(size>limit)throw failure('Request too large',413);chunks.push(b);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}');}catch{throw failure('Invalid JSON');}};
 const updates=new UpdateService({version:JSON.parse(readFileSync(new URL('../package.json',import.meta.url),'utf8')).version,...updateOptions});
 const publicFiles=new Set(['login.html','login.js','update-ui.mjs','update-ui.css','ui.js','portal.css','icon.svg','assets/brand/logo.png','assets/brand/banner.png','assets/brand/app.ico']);
 const redirect=(res,url)=>{res.writeHead(303,{Location:url,'Cache-Control':'no-store'});res.end();};
 const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));};
 const server=http.createServer(async(req,res)=>{
  try{
   if(req.headers.host!==new URL(origin).host)throw failure('Invalid host',403);
   if(req.headers.origin&&req.headers.origin!==origin)throw failure('Invalid origin',403);
   const u=new URL(req.url,origin);
   const decoded=decodeURIComponent(u.pathname);if(decoded.includes('\\')||decoded.includes(':')||/[\x00-\x1f]/.test(decoded)||decoded.split('/').some(p=>p==='..'||/[. ]$/.test(p)))throw failure('Invalid path',403);
   if(u.pathname.startsWith('/api/update/')){
    if(u.pathname==='/api/update/status'&&req.method==='GET'){json(res,200,updates.status());return;}
    if(!['/api/update/check','/api/update/install'].includes(u.pathname)||req.method!=='POST')throw failure('Not found',404);
    const token=req.headers['x-max4-update-token'];
    if(req.headers.origin!==origin||!req.headers['content-type']?.startsWith('application/json')||typeof token!=='string'||Buffer.byteLength(token)!==Buffer.byteLength(updates.token)||!timingSafeEqual(Buffer.from(token),Buffer.from(updates.token)))throw failure('Invalid update request',403);
    const body=await read(req);if(!body||typeof body!=='object'||Array.isArray(body)||Object.keys(body).length)throw failure('Update request accepts no paths or URLs',400);
    json(res,200,u.pathname.endsWith('/check')?await updates.check():updates.install());return;
   }
   if(await membership.handle(req,res,u))return;
   if(u.pathname.startsWith('/monkey/combo/')){
    if(req.method!=='GET')throw failure('GET required',405);
    const got=Buffer.from(u.searchParams.get('key')||''),expected=Buffer.from(key);if(got.length!==expected.length||!timingSafeEqual(got,expected))throw failure('Invalid connector key',403);
    if(!active||Date.now()-active.time>LIVE_LEASE_MS)throw failure('เปิดเกมและเข้าสู่ระบบก่อนรับของขวัญ',409);
    const owner=await membership.getSession({headers:active.headers});if(!owner?.canPlay||owner.user.id!==active.owner)throw failure('บัญชีไม่ได้รับอนุมัติ',403);
    json(res,202,receipts.accept(u.pathname.split('/').at(-1),u.searchParams,owner.user.id));return;
   }
   let session=null;
   if(!publicFiles.has(decoded.slice(1))){
    session=await membership.getSession(req);
    if(!session||(!session.canPlay&&!['hub.html','hub.js'].includes(decoded.slice(1)))){if(req.method==='GET'&&(decoded==='/'||decoded.toLowerCase().endsWith('.html'))){redirect(res,session?'/hub.html':'/login.html');return;}throw failure(session?'รอผู้ดูแลอนุมัติ':'กรุณาเข้าสู่ระบบ',session?403:401);}
   }
   if(u.pathname.startsWith('/api/')){
    if(req.method!=='GET'&&(!membership.csrf(req,session)||req.headers.origin!==origin))throw failure('Invalid CSRF token',403);
    if(u.pathname==='/api/avatar'){
     if(req.method!=='GET')throw failure('GET required',405);
     const image=await avatars.get(u.searchParams.get('url'));
     res.writeHead(200,{'Content-Type':image.type,'Content-Length':image.bytes.length,'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; sandbox",'Cross-Origin-Resource-Policy':'same-origin'});res.end(image.bytes);return;
    }
    if(u.pathname==='/api/control'){
     if(req.method==='GET'){json(res,200,control.status(session.user.id));return;}
     if(req.method==='PUT'){json(res,200,{settings:control.update(session.user.id,await read(req))});return;}
    }
    if(u.pathname==='/api/control/command'&&req.method==='POST'){json(res,200,{command:control.command(session.user.id,await read(req))});return;}
   }
   if(u.pathname==='/api/preset'){if(req.method!=='GET')throw failure('GET required',405);res.setHeader('Content-Disposition','attachment; filename="Monkey-Max4-MonkeyEffect.json"');json(res,200,createPreset(origin,key));return;}
   if(u.pathname==='/api/live/identity'){if(req.method!=='GET')throw failure('GET required',405);json(res,200,{storeId,checkpointVersion:1});return;}
   if(u.pathname==='/api/live/poll'){
    if(req.method!=='POST'||!req.headers['content-type']?.startsWith('application/json'))throw failure('JSON POST required',405);
    const body=await read(req,40*1024*1024);
    if(typeof body.clientId!=='string'||body.clientId.length>100||!Array.isArray(body.acks)||body.acks.length>100||body.inflight!==undefined&&(!Array.isArray(body.inflight)||body.inflight.length>10000||body.inflight.some(id=>typeof id!=='string'||id.length>1024)))throw failure('Invalid poll');
    if(body.storeId!==undefined&&body.storeId!==storeId)throw failure('ตัวรับเปลี่ยน กรุณาปิดจอเกมแล้วเปิดใหม่',409);
    if(active&&active.id===body.clientId&&active.owner!==session.user.id)throw failure('บัญชีเปลี่ยน กรุณาเปิดจอเกมใหม่',401);
    if(active&&active.id!==body.clientId&&Date.now()-active.time<LIVE_LEASE_MS)throw failure('เปิดหน้าเกมเพียงหน้าต่างเดียวเพื่อไม่ให้รับของขวัญซ้ำ',409);
    // Inflight is a delivery cursor, never an acknowledgement. Only a renewed
    // client may skip its own already-started rows; all rows stay durable until ACK.
    const inflight=new Set(active?.id===body.clientId&&active.owner===session.user.id?body.inflight||[]:[]);
    active={id:body.clientId,owner:session.user.id,headers:{cookie:req.headers.cookie},time:Date.now()};receipts.ack(body.acks.filter(id=>receipts.pending.get(id)?.owner===session.user.id));
    json(res,200,{...control.poll(session.user.id,body),bridge:true,verifiedAt:active.time,received:receipts.received,pending:[...receipts.pending.values()].filter(r=>r.owner===session.user.id).length,archived:receipts.archived,recovered:receipts.recovered||0,events:[...receipts.pending.values()].filter(r=>r.owner===session.user.id&&!inflight.has(r.id)).slice(0,50).map(({id,action,name,quantity,user,combo,total,comboEnd})=>({id,action,name,quantity,...(user?{user}:{}),...(combo?{comboId:combo,comboTotal:total,comboEnd}: {})}))});return;
   }
   if(req.method!=='GET'&&req.method!=='HEAD')throw failure('GET required',405);
   if(u.pathname==='/'||u.pathname==='/index.html'){redirect(res,'/hub.html');return;}
   const name=decoded.slice(1);const file=path.resolve(dist,name);if(!file.startsWith(dist+path.sep))throw failure('Invalid path',403);
   let bytes;try{bytes=readFileSync(file);}catch{throw failure('Not found',404);}
   const types={'.html':'text/html; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.ico':'image/x-icon','.woff2':'font/woff2','.wav':'audio/wav','.mp4':'video/mp4','.webm':'video/webm','.json':'application/json; charset=utf-8'};
   const headers={'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Accept-Ranges':'bytes','Content-Security-Policy':`default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: ${AVATAR_CSP}; media-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'self'`};
   let status=200;if(req.headers.range){const m=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range);const total=bytes.length;let start=0,end=total-1;if(!m||(!m[1]&&!m[2])){res.writeHead(416,{'Content-Range':`bytes */${total}`});res.end();return;}if(m[1]){start=Number(m[1]);end=m[2]?Math.min(Number(m[2]),total-1):end;}else start=Math.max(0,total-Number(m[2]));if(start>end||start>=total||!Number.isSafeInteger(start)||!Number.isSafeInteger(end)){res.writeHead(416,{'Content-Range':`bytes */${total}`});res.end();return;}headers['Content-Range']=`bytes ${start}-${end}/${total}`;bytes=bytes.subarray(start,end+1);status=206;}
   headers['Content-Length']=bytes.length;res.writeHead(status,headers);res.end(req.method==='HEAD'?undefined:bytes);
  }catch(e){json(res,e.status||400,{ok:false,error:e.message});}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});origin=`http://127.0.0.1:${server.address().port}`;
 membership=createLiveMembership({origin,reply:json,fetchImpl:membershipFetch});
 return{origin,receipts,updates,close:()=>new Promise(r=>{server.closeAllConnections();server.close(r);})};
}
