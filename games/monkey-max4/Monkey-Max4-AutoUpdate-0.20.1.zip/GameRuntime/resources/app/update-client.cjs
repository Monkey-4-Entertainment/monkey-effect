const fs=require('node:fs'),fsp=require('node:fs/promises'),path=require('node:path');
const {spawn,execFile}=require('node:child_process');
const samePath=(a,b)=>path.resolve(a).toLowerCase()===path.resolve(b).toLowerCase();
function run(file,args,options={}){return new Promise((resolve,reject)=>execFile(file,args,{windowsHide:true,timeout:30000,maxBuffer:1024*1024,...options},(error,stdout)=>error?reject(error):resolve(stdout)));}
async function noLinks(target){
 const absolute=path.resolve(target),parsed=path.parse(absolute);let at=parsed.root;
 for(const part of absolute.slice(parsed.root.length).split(path.sep)){at=path.join(at,part);try{if((await fsp.lstat(at)).isSymbolicLink())throw Error('โฟลเดอร์อัปเดตเป็นทางเชื่อม กรุณาย้ายเกมไปโฟลเดอร์ปกติ');}catch(error){if(error.code!=='ENOENT')throw error;}}
}
function createDesktopUpdateOptions({bundleRoot,appDirectory,execPath=process.execPath,pid=process.pid,parentPid=process.ppid,beforeShutdown=async()=>{},cancelShutdown=async()=>{},shutdown=()=>{}}){
 const root=path.resolve(bundleRoot),runtime=path.join(root,'GameRuntime'),helper=path.join(appDirectory,'Max4Updater.exe');
 if(process.platform!=='win32'||!samePath(execPath,path.join(runtime,'Monkey-Max4-Game.exe'))||!fs.existsSync(path.join(root,'Monkey-Max4.exe')))return {};
 const downloadRoot=path.join(root,'Data','Updates');
 return {downloadRoot,onInstall:async request=>{
  const job=path.resolve(request.job);if(path.dirname(job).toLowerCase()!==downloadRoot.toLowerCase())throw Error('โฟลเดอร์อัปเดตไม่อยู่ในเกมนี้');
  await noLinks(root);await noLinks(job);if(!fs.existsSync(helper))throw Error('ไม่พบตัวติดตั้งอัปเดต กรุณาใช้ชุดเกมล่าสุด');
  const copied=path.join(job,'Max4Updater.exe');await fsp.copyFile(helper,copied,fs.constants.COPYFILE_EXCL);
  const args=['--root',root,'--zip',request.archive,'--sha256',request.sha256,'--size',String(request.bytes),'--current-version',request.currentVersion,'--target-version',request.targetVersion,'--job',job,'--wait-pid',String(pid)];
  try{
   const parent=String(await run('powershell.exe',['-NoLogo','-NoProfile','-NonInteractive','-Command','[System.Diagnostics.Process]::GetProcessById([int]$env:MAX4_PARENT_PID).MainModule.FileName'],{env:{...process.env,MAX4_PARENT_PID:String(parentPid)}})).trim();
   if(samePath(parent,path.join(root,'Monkey-Max4.exe')))args.push('--launcher-pid',String(parentPid));
  }catch{}
  // Validate before closing any game window. The helper verifies again after exit.
  try{await run(copied,[...args,'--verify-only'],{timeout:60000});}catch{throw Error('ตรวจแพ็กอัปเดตไม่ผ่าน เกมปัจจุบันยังใช้งานต่อได้');}
  const proof=JSON.parse(await fsp.readFile(path.join(job,'update-result.json'),'utf8'));if(!proof.ok||proof.installed)throw Error('ตัวติดตั้งยืนยันไฟล์อัปเดตไม่สำเร็จ');
  await beforeShutdown();
  try{
   // The launcher starts Electron inside GameRuntime. Do not let the updater
   // inherit that directory: Windows would then lock the folder it must replace.
   const child=spawn(copied,args,{cwd:job,detached:true,stdio:'ignore',windowsHide:true});
   await new Promise((resolve,reject)=>{child.once('error',reject);child.once('spawn',resolve);});child.unref();
  }catch(error){await cancelShutdown();throw error;}
  // Let the HTTP response reach the login page before closing this runtime.
  setTimeout(shutdown,650);
 }};
}
module.exports={createDesktopUpdateOptions};
